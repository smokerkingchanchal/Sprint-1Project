package com.anudip.crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCrudApplication {
//main method
	public static void main(String[] args) {
		SpringApplication.run(SpringBootCrudApplication.class, args);
	}//end of main method

}//end of class
